import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

normalVar = pd.DataFrame(np.random.normal(5,15,70))
normalVar.columns = ['value']
normalVar.head(70)

normalVar.to_csv('zad2a.csv')

sns.distplot(normalVar)
plt.show()